#ifndef UTILITIES_H
#define UTILITIES_H
#include<utility>
#include<cstdint>

double get_time_sec();

#endif // UTILITIES_H
